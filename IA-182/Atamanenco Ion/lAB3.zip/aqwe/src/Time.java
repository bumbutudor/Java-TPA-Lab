import java.util.Calendar;
import java.util.GregorianCalendar;

public class Time {
        GregorianCalendar time = new GregorianCalendar();
        int hour, min, day, month, year;
        void getTime(){
            hour = time.get(Calendar.HOUR_OF_DAY);
            min = time.get(Calendar.MINUTE);
            day = time.get(Calendar.DAY_OF_MONTH);
            month = time.get(Calendar.MONTH) + 1;
            year = time.get(Calendar.YEAR);
            System.out.println("Timpul curent este: \t" + hour + ":" + min);
            System.out.println("Data de azi este: \t" + month + "/" + day + "/"
                    + year);
        }
    }
        class sayTime extends Time {
            void sayTime() {
                hour = time.get(Calendar.HOUR_OF_DAY);
                if (hour < 12)
                    System.out.println("Este dimineața!");
                else if (hour < 17 && !(hour == 12))
                    System.out.println("Este după amiază");
                else if (hour == 12)
                    System.out.println("Este amiază");
                else
                    System.out.println("Este seara");
            }

        }
           class Main{
            public static void main(String[] args) {
                Time t1= new Time();
                sayTime t2 = new sayTime();
                t1.getTime();
                t2.sayTime();
            }
        }



/*În urma acestei lucrări de laborator am căpătat experiență în lucrul cu moștenirea claselor. Am folosit biblioteci java
pentru lucrul cu timpul curent pe care cu succes l-am afișat și prin intermediul lui am dedus timpul zilei.
Această lucrare de laborator îmi va fi de mare folos ca experiență pentru viitoarele mele realizări.
 */
