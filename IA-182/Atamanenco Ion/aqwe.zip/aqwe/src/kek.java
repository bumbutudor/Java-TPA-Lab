import java.util.Scanner;
class kek {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("Introduceti propozitia: ");
        String n = in.nextLine();
        String[] parts = n.split(" ");
        for (String part : parts) {
            if (part.charAt(0) == part.charAt(part.length() - 1)) {
                System.out.println(part);
            }
        }
    }
}
/* În acest program am efectuat căutarea în text a cuvintelor ce incep și se termin cu aceeasi literă. Am folosit metoda "split" pentru a
împarte stringul prin spații goale " ". String.chartAt(0) va lua caracterele de pe pozitia 0(inceputul) spe lungimea stringului -1.
Dacă ambele litere de la început și sfârșit sunt identice atunci atunci ele se printează.
 */
